// auth.ts
import jwt from 'express-jwt';
import { domain, audience } from './tsconfig.json';

const authenticate = jwt({
  secret: `https://${domain}/.well-known/jwks.json`,
  audience: audience,
  algorithms: ['RS256'],
});

export default authenticate;