export const domain = 'your-auth0-domain.com';
export const audience = 'https://your-api-identifier.com';