const config = {
  authRequired: false,
  auth0Logout: true,
  secret: 'ETRW9XrfR4ysgS0caOfSO0pjIwcEUxhNfE4uR_j5L_9cwKfiyhQzUQgO7H4ln8xt',
  baseURL: 'https://localhost:5000',
  issuerBaseURL: 'https://asgola.auth0.com',
  clientID: 'm8GlIhuB4B9cz8HU1m0ucmJmRCnsb9e2',
  clientSecret: 'your-client-secret', // add your client secret here
  audience: 'https://asgola.auth0.com/api/v2/',
  domain: 'asgola.auth0.com', // add your auth0 domain here
};

export default config;